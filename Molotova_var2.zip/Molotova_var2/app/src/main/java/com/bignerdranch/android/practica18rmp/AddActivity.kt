package com.bignerdranch.android.practica18rmp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson

class AddActivity : AppCompatActivity() {
    private lateinit var numberEditText: EditText
    private lateinit var typeEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        numberEditText = findViewById(R.id.number)
        typeEditText = findViewById(R.id.textQes)
    }

    fun save(view: View) {
        if (numberEditText.text.toString().isEmpty() || typeEditText.text.toString().isEmpty()){
            val i = Toast.makeText(this, "Введите имя и номер контакта.", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 160)
            i.show()

        }
        else{
            val number = numberEditText.text.toString()
            val type = typeEditText.text.toString()
            val ticket = Ticket(number, type)
            val tickets = SharedPreferencesHelper.loadTickets(this).toMutableList()
            tickets.add(ticket)
            SharedPreferencesHelper.saveTickets(this, tickets)

            val i = Toast.makeText(this, "Контакт $type добавлен.", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 160)
            i.show()

            numberEditText.text = null
            typeEditText.text = null
        }

    }
    fun look(view: View) {val intent = Intent(this, LookActivity::class.java)
        startActivity(intent)}


}