package com.bignerdranch.android.practica18rmp


import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Gravity
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    private lateinit var login: EditText
    private lateinit var password: EditText
    private lateinit var sharedPreferences: SharedPreferences

    var loginCheak = sharedPreferences.getString("login", null)
    var passwordCheak = sharedPreferences.getString("password", null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun perehod() {
        login = findViewById(R.id.login)
        password = findViewById(R.id.pass)
        if (login.text.toString().isEmpty() || password.text.toString().isEmpty()){
            val i = Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 160)
            i.show()

        }
        else if(login.text.toString() != loginCheak || password.text.toString() != passwordCheak){
            val i = Toast.makeText(this, "логин и пароль не совпадает", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 160)
            i.show()
        }
        else{
            val intent = Intent(this, AddActivity::class.java)
            startActivity(intent)
        }

    }

    fun register() {
        login = findViewById(R.id.login)
        password = findViewById(R.id.pass)
        if (login.text.toString().isEmpty() || password.text.toString().isEmpty()){
            val i = Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 160)
            i.show()

        }
        else{
            loginCheak = login.text.toString()
            passwordCheak = password.text.toString()
        }

    }
}